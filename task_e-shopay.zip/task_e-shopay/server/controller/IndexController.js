import CategoryController from "./CategoryController";
import ProductController from "./ProductController";
import ProductImgCtrl from './ProductImageController';

export default {
    CategoryController,
    ProductController,
    ProductImgCtrl
}