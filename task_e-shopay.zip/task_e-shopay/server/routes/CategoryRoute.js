import { Router } from "express";
import IndexController from "../controller/IndexController";

const router = Router();

// get method
router.get("/rawSQL",IndexController.CategoryController.findCategoryBySQL);
router.get("/",IndexController.CategoryController.findAllRows);
router.get("/:id",IndexController.CategoryController.findRowById);


// post method
router.post("/",IndexController.CategoryController.createRow);

// put method
router.put("/:id",IndexController.CategoryController.updateRow);

// delete method
router.delete("/:id",IndexController.CategoryController.deleteRow);



export default router;