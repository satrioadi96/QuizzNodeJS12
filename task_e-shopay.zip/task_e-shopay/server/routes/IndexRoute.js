import CategoryRoute from './CategoryRoute';
import ProductRoute from './ProductRoute'

export default {
    CategoryRoute,
    ProductRoute
}