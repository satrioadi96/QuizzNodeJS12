import { Router } from "express";
import IndexController from "../controller/IndexController";
import UpDownloadHelper from "../helpers/UpDownloadHelper";

const router = Router();

// get method
router.get("/",IndexController.ProductController.findAllRows);
router.get("/images/:filename",UpDownloadHelper.showProductImage);


router.post("/",IndexController.ProductController.createProduct);
router.post("/multipart",IndexController.ProductController.createProductImage,
IndexController.ProductImgCtrl.createProductImage,
IndexController.ProductImgCtrl.findProdImagesById);


router.put("/:id",IndexController.ProductController.updateProduct);




export default router;