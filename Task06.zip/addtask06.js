// 1

function duplicateElement(array) {

    const result = array.reduce( (arrayCount, currentArray) => {
        typeof arrayCount[currentArray] !== "undefined" ?
        (arrayCount[currentArray]++) :(arrayCount[currentArray]=1)
    }, {})

    const countArray = result.reduce( ( i ,result) => {
        countArray.push(i + ": " + result[i])
    },[]);
    
    return countArray;
} 

const students = ["asep","budi","charlie","budi","jeni","asep"];
console.log(duplicateElement(students));
//{asep: 2, budi: 2, charlie: 1, jeni: 1}