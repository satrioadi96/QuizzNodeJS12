// buat class untuk menapung data elektronik

// 1
export default class Product {
    constructor(prodID = 0,prodName,category = "ELECTRONIC",price = 0,jumlahBeli = 0){ //, subTotal = 0
        this.prodID = prodID;
        this.prodName = prodName;
        this.category = category;
        this.price = price;
        this.jumlahBeli = jumlahBeli;
        this.subTotal = this.price * this.jumlahBeli;
    }

    setPrice(price){
        this.price = price;
        return this.subTotal = this.price * this.jumlahBeli;
    }

    setPriceJumlahBeli(price,jumlahBeli){
        this.price = price;
        this.jumlahBeli = jumlahBeli;
        return this.subTotal = this.price * this.jumlahBeli;
    }

    toString(){
        
        return `\n--------------------------------------------------------------------\n`+
               `| ID Produk : ${this.prodID}\t| Nama Produk : ${this.prodName}\t|\n
                | Kategori : ${this.category}\t| Harga : ${this.price}\t|\n
                | Jumlah Beli : ${this.jumlahBeli}\t| Subtotal : ${this.subTotal}\n`+
                `--------------------------------------------------------------------\n`;
    }
}


class Discount extends Product{
    constructor(prodID = 0,prodName,category = "ELECTRONIC",price = 0,jumlahBeli = 0, subTotal = 0,discount = 0.00){
        super(prodID,prodName,category ,price ,jumlahBeli, subTotal);
        this.discount = discount;
    }
    
    toString(){
            return super.toString() +
            `Harga Beli : ${this.price}\n
            Jumlah Beli : ${this.jumlahBeli}\n
            Diskon : ${this.discount}\n
            Total Tagihan : ${(this.subTotal * (100 + this.discount))/100}`;
    }

}

export {Discount}