// 1

function duplicateElement(array) {

    const result = array.reduce(
        function(arrayCount, currentArray){
            if(typeof arrayCount[currentArray] !== "undefined"){
                arrayCount[currentArray]++; 
              return arrayCount;
            } else {
                arrayCount[currentArray]=1; 
                return arrayCount;
            }
        }, {})

    const countArray = [];
    for(const i in result){
        countArray.push(i + ": " + result[i]);
    }

    return result;
} 

const students = ["asep","budi","charlie","budi","jeni","asep"];
console.log(duplicateElement(students));
//{asep: 2, budi: 2, charlie: 1, jeni: 1}