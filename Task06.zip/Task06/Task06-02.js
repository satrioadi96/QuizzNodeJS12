import Product from "./Product.js";

const prdct1 = new Product(1, "Samsung A1", "HP", 2500000, 3);
const prdct2 = new Product(2, "Dell Ultrabook", "COMPUTER", 7850000, 2);
const prdct3 = new Product(3, "Mesin Cuci LG", "ELECTRONIC", 3500000, 1);
const prdct4 = new Product(4, "Iphone 12", "HP", 6000000, 2);
const prdct5 = new Product(5, "Asus Laptop", "COMPUTER", 6500000, 4);

// declare listcart
let listCart = [];

const addToCart1 = (list) => {
    listCart = [...listCart,list];
    return listCart;
}

const addToCart2 = (price) => {
  const result =  addToCart1(listCart).filter((el) => el.price > price);
  return result;
}

addToCart1(prdct1);
addToCart1(prdct2);
addToCart1(prdct3);
addToCart1(prdct4);
addToCart1(prdct5);


const findAllProducts = (list) => {
    return list;
}

const createOrder = (year, month, day) => {
    const orderDay = new Date();
    const seq_number = Math.floor(Math.random() * 100 + 100);
    year = orderDay.getFullYear();
    month = orderDay.getMonth();
    day = orderDay.getDate();
    
    return `${year}0${month}${day}#0${seq_number}`;
};

const payment = () => {
    const array = ["BCA", "Shopee Pay","OVO"];
    return array[Math.floor(Math.random() * items.length)];
}

const finalSubTotal = (list) => {
    const totalTagihan = list.reduce((sum, val) => sum + val.subTotal, 0);
    return totalTagihan;
};

const orderStepCustomer = async (list) => {
  const addToCart = await addToCart2(3000000);

  const createOrder = await createOrder(2021, 9, 13);

  const allProducts = await findAllProducts(addToCart);

  const payment = await payment();

  const total = await finalSubTotal(allProducts);

  return `----------------------------------------------------------\n`
  + [createOrder] + `\n` + [allProducts] + `\n`
  + [payment] + `\n` + [total]
       + `----------------------------------------------------------\n`;
};

// call order kfc
orderStepCustomer(listCart).then((prod) => console.log(prod));

console.log();

console.log();
console.log();
console.log();
console.log();
console.log();
console.log();
