import Product, { Discount } from "./Product.js";


const product1 = new Product(1,"Samsung A1","HP",2500000,3);
const product2 = new Product(2,"Dell Ultrabook","COMPUTER",7850000,2);
const product3 = new Product(3,"Mesin Cuci LG","ELECTRONIC",3500000,1);
const product4 = new Product(4,"Iphone 12","HP",6000000,2);
const product5 = new Product(5,"Asus Laptop","COMPUTER",6500000,4);

const listProducts = [
    product1,
    product2,
    product3,
    product4,
    product5
];

// 2
function addProduct(product){
    listProducts.push(product);
    return `Produk baru telah ditambahkan dalam Daftar!`;
}

// 3
function findAllProduct(list){
    return list.toString();
}

// 3-1
function findProductByCategory(list,ctgry){
    return findAllProduct(list.filter(prd => prd.category === ctgry)) ;
}

// 4
function totalProduct(list){
    const totalHargaBeli = list.reduce((total,product) => total+product.subTotal,0);
    return `Total Harga Beli : Rp.${totalHargaBeli}` ;
} 

// 5
function totalTagihan(list,discount){
    let diskon = [];
    for (let i = 0; i < list.length; i++) {
        
        if (list[i].jumlahBeli > 1) {
            diskon[i] = new Discount(list[i],discount);
            diskon.push(diskon[i]);
        } else if(list[i].jumlahBeli === 1){
            diskon[i] = new Discount(list[i],0);
            diskon.push(diskon[i]);
        }
        
    }
    const totalTagihan = diskon.reduce((total,product) => total+(product.subTotal * (100 + product.discount))/100 ,0);
    
    return `Total Tagihan : Rp.${totalTagihan}` ;
    
}







const product6 = new Product(6,"Asus X441UV","COMPUTER",4500000,1);
const product7 = new Product(7,"Sony XZ Performance","HP",1450000,2);
console.log(addProduct(product6));
console.log(addProduct(product7));

console.log(findAllProduct(listProducts));
console.log(totalProduct(listProducts));

console.log(totalTagihan(listProducts,10));

//console.log(listProducts.length);

console.log(findProductByCategory(list,"ELECTRONIC"));


console.log();
console.log();
console.log();
console.log();








//return listProducts; //.toString();
//return `Total Harga Beli : Rp.${totalHargaBeli}`
//diskon.toString(); 