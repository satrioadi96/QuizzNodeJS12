
const deret1 = () => {
    for (let a = 1; a <=7; a++) {
        let x = ' ';
        for (let b = 0; b < a; b++) {
            x += (a+b) + ' ' ;
        }
        console.log(x);
    }
    return '';
}

//console.log(deret1());


const deret2 = () => {
    for (let a = 5; a <=11; a++) {
        let x = ' ';
        for (let b = 0; b < (a-4); b++) {
            x += (a+b) + ' ' ;
        }
        console.log(x);
    }
    return '';
}

console.log(deret2());


