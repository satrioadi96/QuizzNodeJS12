// 2

function rotateArray(array, rotate) {
  console.log("Result : \n");
  let result3 = new Array();
  result3[0] = array;

  for (let i = 1; i <= rotate; i++) {
    result3[i] = new Array();

    for (let j = 1; j < array.length; j++) {
        result3[i][0] = result3[i-1][array.length - 1];
        result3[i][j] = result3[i-1][j - 1];
    }
    
    console.log(`${result3[i-1]} => ${result3[i]}\n`);  
  }
  
  return '';
}

const arr = [3, 8, 9, 7, 6];
console.log(rotateArray(arr, 3)); // putar 3x

//Result :
/**
[3, 8, 9, 7, 6] => [6, 3, 8, 9, 7]
[6, 3, 8, 9, 7] => [7, 6, 3, 8, 9]
[7, 6, 3, 8, 9] => [9, 7, 6, 3, 8]
*/
