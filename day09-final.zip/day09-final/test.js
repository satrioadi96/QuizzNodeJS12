
const array1 = ["Mangga","Apel","Melon","Pisang","Sirsak","Tomat","Nanas",
"Nangka","Timun","Mangga"]
const array2 = ["Bayam","Wortel","Kangkung","Mangga","Tomat","Kembang Kol",
"Nangka","Timun"]
//console.log(diff_same_array(array1,array2));


const mergeArray = [...array1, ...array2]
    .reduce((acc, val) => 
        acc.set(val, (acc.get(val) || 0) + 1), new Map())

console.log(mergeArray);


const same = [...mergeArray].filter(([k, v]) => v > 1)
    .flat()
    .filter(v => isNaN(v));

console.log(same);

const different = [...mergeArray].filter(([k, v]) => v === 1)
    .flat()
    .filter(v => isNaN(v));

console.log(different);
