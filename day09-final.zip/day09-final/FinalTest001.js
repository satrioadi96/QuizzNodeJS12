// 1 clear

function totalLompat(x, y, k) {
  let result = 0;
  for (let i = 0; true; i++) {
    x += k;
    result++;

    if (x <= y) {
      continue;
    } else {
      break;
    }
  }
  return `Output : ${result}`;
}

// x = posisi awal, y=target posisi, k= jarak tempuh satu kali lompatan
//function totalLompat(x,y,k)

console.log(totalLompat(10, 85, 30));
//Output : 3

// 2 clear

function rotateArray(array, rotate) {
  console.log("Result : \n");
  let result3 = new Array();
  result3[0] = array;

  for (let i = 1; i <= rotate; i++) {
    result3[i] = new Array();

    for (let j = 1; j < array.length; j++) {
      result3[i][0] = result3[i - 1][array.length - 1];
      result3[i][j] = result3[i - 1][j - 1];
    }

    console.log(`${result3[i - 1]} => ${result3[i]}\n`);
  }
}

const arr = [3, 8, 9, 7, 6];
console.log(rotateArray(arr, 3)); // putar 3x

//Result :
/**
[3, 8, 9, 7, 6] => [6, 3, 8, 9, 7]
[6, 3, 8, 9, 7] => [7, 6, 3, 8, 9]
[7, 6, 3, 8, 9] => [9, 7, 6, 3, 8]
*/

// 3

function diff_same_array(arrayA, arrayB) {
  const result_same = new Array();
  const result_diff = new Array();

  for (let i = 0; i < arrayA.length; i++) {
    for (let j = 0; j < arrayB.length; j++) {
      if (arrayA[i] === arrayB[j]) {
        result_same[i] = arrayA[i];
      } else {
        result_diff[i] = arrayB[i];
      }
    }
  }
  console.log(`Result : \n`);

  return `Same = ${result_same}\n` + `\nDifferent = ${result_diff}`;
}

const array1 = [
  "Mangga",
  "Apel",
  "Melon",
  "Pisang",
  "Sirsak",
  "Tomat",
  "Nanas",
  "Nangka",
  "Timun",
  "Mangga",
];
const array2 = [
  "Bayam",
  "Wortel",
  "Kangkung",
  "Mangga",
  "Tomat",
  "Kembang Kol",
  "Nangka",
  "Timun",
];
console.log(diff_same_array(array1, array2));

/** 
Result :
Same = ["Mangga","Tomat","Nangka","Timun"]
Different = ["Apel","Melon","Pisang","Sirsak","Nanas","Bayam","Wortel","Kangkung","Kembang Kol"]
*/

// 4 clear

const deret1 = () => {
  for (let a = 1; a <= 7; a++) {
    let x = " ";
    for (let b = 0; b < a; b++) {
      x += a + b + " ";
    }
    console.log(x);
  }
};

//console.log(deret1());

const deret2 = () => {
  for (let a = 5; a <= 11; a++) {
    let x = " ";
    for (let b = 0; b < a - 4; b++) {
      x += a + b + " ";
    }
    console.log(x);
  }
};

//console.log(deret2());
