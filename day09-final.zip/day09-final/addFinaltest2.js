// 3

function diff_same_array(arrayA,arrayB) {
    const result_same = new Array();
    const result_diff = new Array();

    for (let i = 0; i < arrayA.length; i++) {
        for (let j = 0; j < arrayB.length; j++) {
            if (arrayA[i] === arrayB[j]) {
                result_same[i] = arrayA[i];
            } else {
                result_diff[i] = arrayB[i];
            }
            
        }
        
    }
    console.log(`Result : \n`);

    return `Same = ${result_same}\n`
    +`\nDifferent = ${result_diff}`;
}



const array1 = ["Mangga","Apel","Melon","Pisang","Sirsak","Tomat","Nanas",
"Nangka","Timun","Mangga"]
const array2 = ["Bayam","Wortel","Kangkung","Mangga","Tomat","Kembang Kol",
"Nangka","Timun"]
console.log(diff_same_array(array1,array2));

/** 
Result :
Same = ["Mangga","Tomat","Nangka","Timun"]
Different = ["Apel","Melon","Pisang","Sirsak","Nanas","Bayam","Wortel","Kangkung","Kembang Kol"]
*/
